<?php

return [
    'site_title' => 'senfineco_2',
];
